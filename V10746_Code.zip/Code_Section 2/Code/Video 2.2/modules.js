const fs = require("fs");

const result = fs.readdirSync(__dirname);

console.log(result);
