const chalk = require("chalk");

console.log(chalk.underline.bgRed.blue("Hello, world!"));
